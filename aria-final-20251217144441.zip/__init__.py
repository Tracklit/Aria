"""
Aria API - Core Application Package
AI-powered running coach API integrated with TrackLit platform
"""

__version__ = "0.2.0"
__author__ = "Aria Team"
