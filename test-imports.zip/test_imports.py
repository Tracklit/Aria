#!/usr/bin/env python3
"""
Test script to verify all imports work
"""
import sys
print("Python version:", sys.version)
print("=" * 50)

print("Testing basic imports...")
try:
    import os
    print("✓ os")
except Exception as e:
    print(f"✗ os: {e}")

try:
    import redis
    print("✓ redis")
except Exception as e:
    print(f"✗ redis: {e}")

try:
    import psycopg2
    print("✓ psycopg2")
except Exception as e:
    print(f"✗ psycopg2: {e}")

try:
    import fastapi
    print("✓ fastapi")
except Exception as e:
    print(f"✗ fastapi: {e}")

try:
    import openai
    print("✓ openai")
except Exception as e:
    print(f"✗ openai: {e}")

try:
    import stripe
    print("✓ stripe")
except Exception as e:
    print(f"✗ stripe: {e}")

print("=" * 50)
print("Testing src module imports...")

try:
    from src import database
    print("✓ src.database")
except Exception as e:
    print(f"✗ src.database: {e}")
    import traceback
    traceback.print_exc()

try:
    from src import cache
    print("✓ src.cache")
except Exception as e:
    print(f"✗ src.cache: {e}")
    import traceback
    traceback.print_exc()

try:
    from src import main
    print("✓ src.main")
except Exception as e:
    print(f"✗ src.main: {e}")
    import traceback
    traceback.print_exc()

print("=" * 50)
print("All import tests complete")
